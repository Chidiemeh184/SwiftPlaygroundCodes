/*: 
[Table of Contents](Table%20of%20Contents) | [Previous](@previous) | [Next](@next)
****
# Document Revision History

### August 24, 2015
Updated for Swift 2 beta 6.
### June 8, 2015
A new playground document that describes how to use the Swift standard library.
****
[Table of Contents](Table%20of%20Contents) | [Previous](@previous) | [Next](@next)
*/
